Don't copy database before contact me

Contact:
email:sout.rahim@gmail.com
facebook:Srh Dp