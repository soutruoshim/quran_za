package com.sout_rahim.quran_za.ultils;

/**
 * Created by sout_rahim on 16/07/12.
 */

public interface AdapterItemClickListenerA {
    public void onItemClick(String item,String item1);
    public void onActionClick(int item);
}
