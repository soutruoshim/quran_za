package com.sout_rahim.quran_za.ultils;

/**
 * Created by sout_rahim on 16/07/12.
 */

public interface AdapterItemClickListener {
    public void onItemClick(String item);
}
